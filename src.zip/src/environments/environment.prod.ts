export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBW69DO5d-RSeWSsuqxoOjcQV9bisY5dFc",
    authDomain: "finalwebproject-112c5.firebaseapp.com",
    projectId: "finalwebproject-112c5",
    storageBucket: "finalwebproject-112c5.appspot.com",
    messagingSenderId: "852562954040",
    appId: "1:852562954040:web:609b536647a65c3cf263cd",
    measurementId: "G-PWM1GKZ01V"
  }
};
