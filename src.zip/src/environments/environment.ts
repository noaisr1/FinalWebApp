// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBW69DO5d-RSeWSsuqxoOjcQV9bisY5dFc",
    authDomain: "finalwebproject-112c5.firebaseapp.com",
    projectId: "finalwebproject-112c5",
    storageBucket: "finalwebproject-112c5.appspot.com",
    messagingSenderId: "852562954040",
    appId: "1:852562954040:web:609b536647a65c3cf263cd",
    measurementId: "G-PWM1GKZ01V"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
